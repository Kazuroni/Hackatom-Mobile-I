package br.edu.fatecpg.ui.Controllers

class PessoaController {
}